package com.example.kemayur_uas_pemmob

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
